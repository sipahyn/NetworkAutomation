#! /bin/bash

sudo ip route add 192.168.1.0/24 via 192.168.122.216
sudo ip route add 192.168.23.1/32 via 192.168.122.216
