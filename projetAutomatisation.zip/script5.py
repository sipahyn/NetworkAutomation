from netmiko import ConnectHandler

R3 = {
    'device_type': 'cisco_ios',
    'ip': '192.168.122.216',
    'username': 'nader',
    'password': 'cisco'
}

net_connect = ConnectHandler(**R3)

config_commands_ospf = ['router ospf 100',
			'network 192.168.23.0 0.0.0.3 area 0',
			'default-information originate']

output = net_connect.send_config_set(config_commands_ospf)
print (output)

config_commands_access = ['ip access-list standard NAT',
			  'permit 192.168.10.0 0.0.0.255',
			  'permit 192.168.20.0 0.0.0.255',
			  'deny any']

output = net_connect.send_config_set(config_commands_access)
print (output)

config_commands_nat = ['ip nat inside source list NAT interface f0/1 overload',
                          'int f0/1',
                          'ip nat outside',
                          'int f0/0',
			  'ip nat inside']

output = net_connect.send_config_set(config_commands_nat)
print (output)

#output = net_connect.send_command('wr\n')
#print (output)
