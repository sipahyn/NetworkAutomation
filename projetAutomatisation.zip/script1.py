import getpass
import telnetlib

user = input("Enter your remote account: ")
password = getpass.getpass()

switchs = open ('devices')

for IP in switchs:
    IP=IP.strip()
    print ("Configuring Switch " + (IP))
    HOST = IP
    tn = telnetlib.Telnet(HOST)
    tn.read_until(b"Username: ")
    tn.write(user.encode('ascii') + b"\n")
    if password:
       tn.read_until(b"Password: ")
       tn.write(password.encode('ascii') + b"\n")
    tn.write(b"enable\n")
    tn.write(b"cisco\n")
    tn.write(b"conf t\n")


    for x in range (2,21):
        tn.write(b"vlan " + str(x).encode('ascii') + b"\n")
        tn.write(b"name VLAN_AUTOMATISATION_" + str(x).encode('ascii') + b"\n")
    tn.write(b"vlan 99\n")
    tn.write(b"name blackhole\n")
    tn.write(b"end\n")
#    tn.write(b"wr\n")
#    tn.write(b"\n")
    tn.write(b"exit\n")
    print(tn.read_all().decode('ascii'))
