from netmiko import ConnectHandler

R1 = {
    'device_type': 'cisco_ios',
    'ip': '192.168.1.1',
    'username': 'nader',
    'password': 'cisco'
}

net_connect = ConnectHandler(**R1)

config_commands_ospf = ['router ospf 100',
			'network 192.168.1.0 0.0.0.255 area 0',
			'network 192.168.10.0 0.0.0.255 area 0',
			'network 192.168.20.0 0.0.0.255 area 0',
			'network 192.168.21.0 0.0.0.3 area 0',
			'passive-interface f0/0']
output = net_connect.send_config_set(config_commands_ospf)
print (output)

#output = net_connect.send_command('wr')
#print (output)
