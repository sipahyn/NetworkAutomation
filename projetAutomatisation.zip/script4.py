from netmiko import ConnectHandler

R2 = {
    'device_type': 'cisco_ios',
    'ip': '192.168.23.1',
    'username': 'nader',
    'password': 'cisco'
}

net_connect = ConnectHandler(**R2)

config_commands_ospf = ['router ospf 100',
			'network 192.168.21.0 0.0.0.3 area 0',
			'network 192.168.23.0 0.0.0.3 area 0']
output = net_connect.send_config_set(config_commands_ospf)
print (output)

output = net_connect.send_command('wr')
print (output)
