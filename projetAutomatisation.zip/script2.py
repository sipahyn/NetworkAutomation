import getpass
import telnetlib

user = input("Enter your remote account: ")
password = getpass.getpass()

switchs = open ('devices')

for IP in switchs:
    IP=IP.strip()
    print ("Configuring Switch " + (IP))
    HOST = IP
    tn = telnetlib.Telnet(HOST)
    tn.read_until(b"Username: ")
    tn.write(user.encode('ascii') + b"\n")
    if password:
       tn.read_until(b"Password: ")
       tn.write(password.encode('ascii') + b"\n")
    tn.write(b"enable\n")
    tn.write(b"cisco\n")
    tn.write(b"conf t\n")

    if IP == "192.168.1.10":
        interfaceblackhole = open ('sw1blackhole')
        for int in interfaceblackhole:
            int=int.strip()
            tn.write(b"int " + str(int).encode('ascii') + b"\n")
            tn.write(b"switchport mode access\n")
            tn.write(b"switchport access vlan 99\n")
            tn.write(b"shutdown\n")
    if IP == "192.168.1.11":
        interfaceblackhole = open ('sw2blackhole')
        for int in interfaceblackhole:
            int=int.strip()
            tn.write(b"int " + str(int).encode('ascii') + b"\n")
            tn.write(b"switchport mode access\n")
            tn.write(b"switchport access vlan 99\n")
            tn.write(b"shutdown\n")
    if IP == "192.168.1.12":
        interfaceblackhole = open ('sw3blackhole')
        for int in interfaceblackhole:
            int=int.strip()
            tn.write(b"int " + str(int).encode('ascii') + b"\n")
            tn.write(b"switchport mode access\n")
            tn.write(b"switchport access vlan 99\n")
            tn.write(b"shutdown\n")

    tn.write(b"end\n")
#    tn.write(b"wr\n")
#    tn.write(b"\n")
    tn.write(b"exit\n")
    print(tn.read_all().decode('ascii'))
